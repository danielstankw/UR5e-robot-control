import numpy as np
import numpy.linalg as LA
import Onrobot
import URBasic
import time
from min_jerk_planner import PathPlan
import angle_transformation as at
from Control import Control

# import traceback
# import os
# # ------ this for stopping the while loop with Ctrl+C (KeyboardInterrupt) this has to be at the top of the file!!--------
# os.environ['FOR_DISABLE_CONSOLE_CTRL_HANDLER'] = 'T'



def run_robot_BASE(start_pose, desired_pose, pose_error, which_controller, which_param):
    host = '192.168.1.103'
    robotModle = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=host, robotModel=robotModle)
    robot.reset_error()
    FT_sensor = Onrobot.FT_sensor()

    Controller = Control(which_param=which_param)
    which_controller = which_controller

    # TCP and Payload initialization
    robot.set_tcp(pose=[])
    robot.set_payload_mass(m=1.34)
    # robot.set_payload_cog(CoG=())

    # Add the pose errors to the start and desired poses
    # start_pose = start_pose + pose_error
    # desired_pose = goal_pose + pose_error

    robot.movel(start_pose)
    time.sleep(0.5)  # Wait for the robot/measurements to be stable before starting the insertion
    pose_init = np.array(robot.get_actual_tcp_pose(wait=True))
    vel_init = np.array(robot.get_actual_tcp_speed(wait=False))
    vel_init[3:] = -vel_init[3:]
    #print(f"pose_init = {pose_init}. vel_init {vel_init}")

    # ------- redefining the angles ---------
    Vrot_initial = at.RotationVector(start_pose[3:6], desired_pose[3:6])  # creates rotation vector
    Vrot_curr = Vrot_initial
    # follow trajectory by decreasing magnitude of the rotation vector. example: 5*[0.707,0, -0.707]->0*[0.707,0,-0.707]
    Vrot_desired = np.array([0, 0, 0])

    # ------ Minimum jerk trajectory Initialization --------
    pose_real_init = np.append(start_pose[:3], Vrot_initial)
    pose_real = np.copy(pose_real_init)
    pose_desired = np.append(desired_pose[:3], Vrot_desired)
    time_for_trajectory = 6 #5
    planner = PathPlan(pose_real_init, pose_desired, time_for_trajectory)
    [position_ref, Vrot_ref, lin_vel_ref, ang_vel_ref] = planner.trajectory_planning(0)

    # -------- Impedance model Initialization ------------

    # Here you can set F0 for the impedance control and the force control in Base sys
    F0_imp = np.zeros(6)   #np.array([0, 0, -7, 0, 0, 0])
    F0_fc = np.zeros(6)   #np.array([0, 0, -7, 0, 0, 0])

    # ----------- Control Settings -------------------
    Kp_f = 4500 * np.array([1, 1, 1])
    Kd_f = 2 * 7 * np.sqrt(Kp_f)
    Kp_m = 100 * np.array([1, 1, 1])
    Kd_m = 2 * 0.707 * np.sqrt(Kp_m)

    # ------------ Forces initialization ------------
    force_reading_init = np.copy(robot.get_tcp_force(wait=True))
    F_internal_init = np.copy(force_reading_init)
    F_external_init_Tool = np.copy(FT_sensor.force_moment_feedback())

    # Convert F_external measurements to BASE coordinate system:
    F_ext_force = at.Tool2Base_vec(pose_real_init[3:], F_external_init_Tool[:3])
    F_ext_moment = at.Tool2Base_vec(pose_real_init[3:], F_external_init_Tool[3:])
    F_external_init = np.append(F_ext_force, F_ext_moment)
    print(f"F_external_init(Tool) = {F_external_init_Tool}, F_external_init(Base) = {F_external_init}")

    # ------------- Plot's data initialization ----------------------
    plot_positions = True
    plot_oriantations = True
    plot_forces = True
    plot_moments = True
    t_curr_plot = [0]

    vel_real = np.copy(vel_init)
    pose_ref = np.copy(pose_real_init)
    vel_ref = np.copy(vel_init)
    pose_mod = np.copy(pose_ref)
    vel_mod = np.copy(vel_ref)

    pose_ref_next, vel_ref_next = np.copy(pose_ref), np.copy(vel_ref)
    F_external, force_reading = np.copy(F_external_init), np.copy(force_reading_init)

    if plot_positions or plot_oriantations:
        pose_real_plot = np.copy(pose_real)
        pose_ref_plot = np.copy(pose_ref)
        pose_mod_plot = np.copy(pose_mod)

    if plot_forces or plot_moments:
        F_internal_plot = np.zeros(6)
        F_external_plot = np.zeros(6)
        wrench_fc_plot = np.zeros(6)
        wrench_imp_plot = np.zeros(6)


    # = =   =   =   =   =   =   =   =   Try and Exception with KeyboardInterrupt    =   =   =   =   =   =   =

    try:
        # ------------ Simulation(Loop) setup ----------------
        # Initialize force remote
        robot.set_force_remote(task_frame=[0, 0, 0, 0, 0, 0], selection_vector=[0, 0, 0, 0, 0, 0],
                               wrench=(-force_reading_init), f_type=2, limits=[2, 2, 1.5, 1, 1, 1])

        t_init = time.time()
        t_curr = 0
        flag_hit_surface = False  # flag_hit_surface equals "True" after we hit the surface. than we change to inserting phase.
        time_for_simulation = time_for_trajectory + 5  # 3  # 2 #3

        deviation_from_goal = 0.003  # 0.004  # Deviation from final goal in [m] which break the loop
        wrench_safety_limits = np.array([15,15,15,3,3,3])   #np.array([20,20,20,5,5,5])  #np.array([15,15,15,3,3,3])  #np.array([10, 10, 12, 1.2, 1.2,1.2])  # np.array([20, 20, 20, 2.5, 2.5, 2.5]) #np.array([3, 3, 5, 0.2, 0.2, 0.2]) #np.array([9, 9, 9, 1.2, 1.2, 1.2])  # An absolute values for limiting the wrench commands

        success_flag = False

        #   *   *   *   *   *   *   *   *   = = = = = = = Operation Loop = = = = = = = =    *   *   *   *   *   *   *

        # print('\n* * * * * * *  =  =  =  =  =  =  Simulation Begin =  =  =  =  =  =  * * * * * * *')
        try:
            while t_curr < time_for_simulation:
                t_prev = t_curr
                t_curr = time.time() - t_init
                dt = t_curr - t_prev
                # print(f'\nt = {t_curr} (dt ={dt}):')

                # ---------- Read Sensors -------------------
                pose_reading = robot.get_actual_tcp_pose(wait=True)
                vel_real = robot.get_actual_tcp_speed(wait=False)
                force_reading = robot.get_tcp_force(wait=False)
                F_external_Tool = FT_sensor.force_moment_feedback() - F_external_init_Tool
                Vrot_real = at.RotationVector(pose_reading[3:], desired_pose[
                                                                3:])  # Converting axis angles to Rotation vector (from the current pose to the desired pose)
                pose_real = np.append(pose_reading[:3], Vrot_real)
                vel_real[3:] = -vel_real[
                                3:]  # when working with Vrot method we use the opposite sign of the angular velocity

                # ----------- F/T calibration ----------------
                F_internal = force_reading - force_reading_init
                F_ext_force = at.Tool2Base_vec(pose_reading[3:], F_external_Tool[:3])
                F_ext_moment = at.Tool2Base_vec(pose_reading[3:], F_external_Tool[3:])
                F_external = np.append(F_ext_force, F_ext_moment)
                F_external_normalized = F_external.copy()

                # # Delete2 if not necessary
                # # F/T normalization:
                # F_ext_norm = F_external[:3] / max(1e-10, LA.norm(F_external[:3]))
                # M_ext_norm = F_external[3:] / max(1e-10, LA.norm(F_external[3:]))
                # F_external_normalized = np.append(F_ext_norm, M_ext_norm)


                # print('F_internal =', F_internal, '\nF_external =', F_external, '\nF_ext_tool =', F_external_Tool)

                # --------- Impedance model(generate X_next of the modified trajectory) ----------------
                pose_ref, vel_ref = np.copy(pose_ref_next), np.copy(vel_ref_next)
                # X_next = Controller.Impedance_equation(pose_mod,vel_mod,pose_ref,vel_ref,F_external,F0_imp,dt)

                if which_controller == 'imp':
                    # # For using F_internal as Fint in the impedance equations (Fits to Shir's method/Increasing Vrot oriantation method):
                    # X_next = Controller.Impedance_equation(pose_mod, vel_mod, pose_ref, vel_ref, F_internal, F0_imp, dt)
                    # # # For using F_external as Fint in the impedance equtation (Used for Shir's project):
                    # X_next = Controller.Impedance_equation(pose_mod, vel_mod, pose_ref, vel_ref, F_external, F0_imp, dt)

                    # # For using F_internal as Fint in the impedance equtation !! When using decreasing Vrot oriantation method !!:
                    # X_next = Controller.Impedance_equation(pose_mod, vel_mod, pose_ref, vel_ref,[1, 1, 1, -1, -1, -1] * F_internal, F0_imp, dt)

                    # For using F_external as Fint in the impedance equtation !! When using decreasing Vrot oriantation method !!:
                    X_next = Controller.Impedance_equation(pose_mod, vel_mod, pose_ref, vel_ref, [1,1,1,-1,-1,-1]*F_external_normalized, F0_imp, dt)

                    # if np.abs(F_external[2]) > 2.5 or flag_hit_surface:
                    #     X_next = Controller.Impedance_equation(pose_mod,vel_mod,pose_ref,vel_ref,F_internal,F0_imp,dt)
                    # else:
                    #     X_next = np.append(pose_ref, vel_ref)
                    pose_mod = X_next[:6]
                    vel_mod = X_next[6:]

                    # # Delete!!! Avoid impedance in Z:
                    # pose_mod[2] = pose_ref[2]

                    # For updating pose_mod and vel_mod only after hitting the surface:
                    if not flag_hit_surface:
                        pose_mod = np.copy(pose_ref)
                        vel_mod = np.copy(vel_ref)

                    # Compute wrench:
                    # wrench_fc = Controller.Force_controler(F_external, F_internal, F_internal_init, F0_fc)

                    wrench_imp = Controller.PD_controler(pose_real, pose_mod, vel_real, vel_mod, F_internal_init)

                    # # For resist external forces in Z  (Used for Shir's project):
                    # wrench_imp = Controller.PD_controler(pose_real, pose_mod, vel_real, vel_mod,
                    #                                      [0, 0, 1, 0, 0, 0] * force_reading + [1, 1, 0, 1, 1,
                    #                                                                            1] * F_internal_init)

                    # # Use wrench of -5[N] in Z direction (Used for Shir's project):
                    # wrench_imp[2] = -5 - F_internal_init[2]  # -8.5 - F_internal_init[2]

                # ------------- Minimum Jerk Trajectory updating ----------------------

                # Check if updating reference values with the minimum-jerk trajectory is necessary
                if t_curr <= time_for_trajectory:
                    [position_ref, Vrot_ref, lin_vel_ref, ang_vel_ref] = planner.trajectory_planning(t_curr)
                pose_ref_next = np.append(position_ref, Vrot_ref)
                vel_ref_next = np.append(lin_vel_ref, ang_vel_ref)

                # ----------- - - - - = = = Control = = = - - - - -------------

                # # For PD only (without impedance):
                if which_controller == 'PD':
                    # print(f'check!!!!')
                    Controller.A_imp_inv = 0 * Controller.A_imp
                    force_command = 300 * (pose_ref[:3] - pose_real[:3]) + 30 * (
                                vel_ref[:3] - vel_real[:3]) - F_internal_init[:3]
                    moment_command = 4 * (pose_real[3:] - pose_ref[3:]) + 1 * (
                                vel_real[3:] - vel_ref[3:]) - F_internal_init[3:]
                    wrench_PD = np.append(force_command, moment_command)
                    # Use wrench of -5[N] in Z direction:
                    wrench_PD[2] = -5 - F_internal_init[2]  # -8.5 - F_internal_init[2]

                # wrench_PD_imp = Controller.PD_controler(pose_real, pose_mod, vel_real, vel_mod, force_reading)
                # For checking
                # wrench_PD_imp[2] = -5-F_internal_init[2]
                # wrench_PD_imp = np.array([0,0,-5,0,0,0])-F_internal_init

                # Enter insertion mode only if F_external in the direction of the insertion is above the threshold
                if np.abs(F_external[2]) > 2.5 or flag_hit_surface:
                    if not (flag_hit_surface):
                        time_insertion_mode = t_curr
                        print('Entered insertion mode at time:', time_insertion_mode)
                        flag_hit_surface = True

                    if which_controller == 'PD':
                        wrench_task = np.copy(wrench_PD)
                    elif which_controller == 'imp':
                        wrench_task = np.copy(wrench_imp)


                    else:
                        raise RuntimeError(
                            f'!!Error in the Operation loop: "which_controller"={which_controller} is not a name of a known controler!')

                else:
                    # PD Controller for the free space:
                    force_command = Kp_f * (pose_ref[:3] - pose_real[:3]) + Kd_f * (
                            vel_ref[:3] - vel_real[:3]) - force_reading[:3]
                    moment_command = Kp_m * (pose_real[3:] - pose_ref[3:]) + Kd_m * (
                            vel_real[3:] - vel_ref[3:]) - force_reading[3:]
                    wrench_task = np.append(force_command, moment_command)

                # ---------------- Sending the wrench_fc to the robot --------------------

                # print('wrench_task:', wrench_task)

                # Verify wrench safety limits:
                wrench_safety_criterion = np.abs(wrench_task) > wrench_safety_limits
                if wrench_safety_criterion.any():
                    # print('wrench safety limits is on')
                    not_wrench_safety_criterion = np.logical_not(wrench_safety_criterion)
                    wrench_task = (not_wrench_safety_criterion * wrench_task) + (
                            wrench_safety_criterion * wrench_safety_limits * np.sign(wrench_task))
                # print('wrench_task after verifying safety limits:', wrench_task)

                robot.set_force_remote(task_frame=[0, 0, 0, 0, 0, 0], selection_vector=[1, 1, 1, 1, 1, 1],
                                       wrench=wrench_task, f_type=2, limits=[2, 2, 1.5, 1, 1, 1])

                # --------------- Collecting Plot's data ---------------------------
                t_curr_plot.append(t_curr)

                if plot_positions or plot_oriantations:
                    pose_real_plot = np.vstack((pose_real_plot, pose_real))
                    pose_ref_plot = np.vstack((pose_ref_plot, pose_ref))
                    pose_mod_plot = np.vstack((pose_mod_plot, pose_mod))

                if plot_forces or plot_moments:
                    F_internal_plot = np.vstack((F_internal_plot, F_internal))
                    F_external_plot = np.vstack((F_external_plot, F_external))
                    # wrench_fc_plot = np.vstack((wrench_fc_plot, wrench_fc + F_internal_init))
                    wrench_imp_plot = np.vstack((wrench_imp_plot, wrench_task + F_internal_init))

                # ---------- Stop simulation if the robot reaches the goal (regarding to the err acceptable deviation) --------
                if np.abs(pose_real[2] - desired_pose[2]) <= deviation_from_goal:
                    print(f"Goal is reached!!! at time {t_curr}")
                    robot.set_force_remote(task_frame=[0, 0, 0, 0, 0, 0], selection_vector=[0, 0, 0, 0, 0, 0],
                                           wrench=[0, 0, 0, 0, 0, 0], f_type=2, limits=[2, 2, 1.5, 1, 1, 1])
                    robot.end_force_mode()
                    robot.reset_error()
                    success_flag = True
                    break

        except Exception as e:  # (Exception, KeyboardInterrupt) as e:
            print("Error has occurred during the simulation")
            print(e)
            success_flag = 'error'
            # traceback.print_exc()
            robot.set_force_remote(task_frame=[0, 0, 0, 0, 0, 0], selection_vector=[0, 0, 0, 0, 0, 0],
                                   wrench=[0, 0, 0, 0, 0, 0], f_type=2, limits=[2, 2, 1.5, 1, 1, 1])
            robot.end_force_mode()
            # robot.reset_error()
            # robot.close()

    except KeyboardInterrupt:
        print("\n!! Ctrl+C Keyboard Interrupt !!\n")
        success_flag = 'interrupt'
        robot.set_force_remote(task_frame=[0, 0, 0, 0, 0, 0], selection_vector=[0, 0, 0, 0, 0, 0],
                               wrench=[0, 0, 0, 0, 0, 0], f_type=2, limits=[2, 2, 1.5, 1, 1, 1])
        robot.end_force_mode()
        print('\nended force mode.\n')
        robot.reset_error()
        robot.close()
        print('closed the robot (finish the RTDE communication)')
        return success_flag

    # = =   =   =   =   =   =   =   = End of KeyboardInterrupt Try and Exception    =   =   =   =   =   =   =



    # Stop the robot and End the force mode
    robot.set_force_remote(task_frame=[0, 0, 0, 0, 0, 0], selection_vector=[0, 0, 0, 0, 0, 0],
                           wrench=[0, 0, 0, 0, 0, 0], f_type=2, limits=[2, 2, 1.5, 1, 1, 1])
    robot.end_force_mode()
    print('\nended force mode.\n')

    # # Print final errors that result from the simulation
    # pose_curr = np.array(robot.get_actual_tcp_pose(wait=True))
    # print(f"final error in x is {(np.abs(pose_curr[0] - desired_pose[0]))} for robot")
    # print(f"final error in y is {(np.abs(pose_curr[1] - desired_pose[1]))} for robot")
    # print(f"final error in z is {(np.abs(pose_curr[2] - desired_pose[2]))} for robot")
    # print(f"Total time of simulation {time.time() - t_init}")

    # End the communication with the robot
    robot.movel(start_pose - pose_error)
    robot.reset_error()
    robot.close()

    print('closed the robot (finish the RTDE communication)')

    return success_flag